<?php

namespace WSCTS;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;

if (! defined('ABSPATH')) {
    exit;
}

class Custom_Testimonial_Slider extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'custom_testimonial_slider';
    }

    public function get_title()
    {
        return __('Custom Testimonial Slider', 'ws-custom-testimonial-slider');
    }

    public function get_icon()
    {
        return 'eicon-testimonial-carousel';
    }

    public function get_categories()
    {
        return ['general'];
    }

    public function get_style_depends()
    {
        return ['wscts-frontend'];
    }

    public function get_script_depends()
    {
        return ['wscts-frontend'];
    }

    protected function register_controls()
    {
        // Content: Layout Settings
        $this->start_controls_section('layout_section', [
            'label' => __('Layout Settings', 'ws-custom-testimonial-slider'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('effect', [
            'label' => __('Effect', 'ws-custom-testimonial-slider'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'slide' => __('Slide', 'ws-custom-testimonial-slider'),
                'fade' => __('Fade', 'ws-custom-testimonial-slider'),
                'cube' => __('Cube', 'ws-custom-testimonial-slider'),
                'cards' => __('Cards', 'ws-custom-testimonial-slider'),
                'coverflow' => __('Coverflow', 'ws-custom-testimonial-slider'),
            ],
            'default' => 'slide',
        ]);

        $this->add_control('thumbnail_position', [
            'label' => __('Thumbnail Position', 'ws-custom-testimonial-slider'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'bottom' => __('Bottom', 'ws-custom-testimonial-slider'),
                'top' => __('Top', 'ws-custom-testimonial-slider'),
            ],
            'default' => 'top',
            'condition' => [
                'effect' => ['slide', 'fade'],
            ],
        ]);

        $this->add_control('enable_autoplay', [
            'label' => __('Enable Autoplay', 'ws-custom-testimonial-slider'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'yes',
        ]);

        $this->add_control('autoplay_speed', [
            'label' => __('Autoplay Speed (ms)', 'ws-custom-testimonial-slider'),
            'type' => Controls_Manager::NUMBER,
            'default' => 3000,
            'condition' => ['enable_autoplay!' => ''],
        ]);

        $this->add_control('transition_speed', [
            'label' => __('Transition Speed (ms)', 'ws-custom-testimonial-slider'),
            'type' => Controls_Manager::NUMBER,
            'default' => 600,
        ]);

        $this->add_control('nav_type', [
            'label' => __('Navigation Type', 'ws-custom-testimonial-slider'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'arrows' => __('Arrows', 'ws-custom-testimonial-slider'),
                'dots' => __('Dots', 'ws-custom-testimonial-slider'),
                'both' => __('Both', 'ws-custom-testimonial-slider'),
                'none' => __('None', 'ws-custom-testimonial-slider'),
            ],
            'default' => 'both',
        ]);

        $this->end_controls_section();

        // Container Style (merged)
        $this->start_controls_section('style_container', ['label' => __('Container Style', 'ws-custom-testimonial-slider'), 'tab' => Controls_Manager::TAB_STYLE]);
        $this->add_group_control(Group_Control_Background::get_type(), [
            'name' => 'container_background',
            'types' => ['classic', 'gradient'],
            'selector' => '{{WRAPPER}} .wscts-slider',
        ]);
        $this->add_group_control(Group_Control_Border::get_type(), [
            'name' => 'container_border',
            'selector' => '{{WRAPPER}} .wscts-slider',
        ]);
        $this->add_responsive_control('container_border_radius', [
            'label' => __('Border Radius', 'ws-custom-testimonial-slider'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px','em','rem','%','custom'],
            'selectors' => ['{{WRAPPER}} .wscts-slider' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
        ]);
        $this->add_responsive_control('container_padding', [
            'label' => __('Padding', 'ws-custom-testimonial-slider'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px','em','rem','%','custom'],
            'selectors' => ['{{WRAPPER}} .wscts-slider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
        ]);
        $this->add_responsive_control('container_margin', [
            'label' => __('Margin', 'ws-custom-testimonial-slider'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px','em','rem','%','custom'],
            'selectors' => ['{{WRAPPER}} .wscts-slider' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
        ]);
        $this->add_responsive_control('container_width', [
            'label' => __('Width', 'ws-custom-testimonial-slider'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px','%','em','rem','custom'],
            'selectors' => ['{{WRAPPER}} .wscts-slider' => 'width: {{SIZE}}{{UNIT}};'],
        ]);
        $this->add_responsive_control('container_height', [
            'label' => __('Height', 'ws-custom-testimonial-slider'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px','%','em','rem','custom'],
            'selectors' => ['{{WRAPPER}} .wscts-slider' => 'min-height: {{SIZE}}{{UNIT}};'],
        ]);
        $this->add_responsive_control('container_max_width', ['label' => __('Max Width', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units'=>['px','%','em','rem','custom'], 'selectors' => ['{{WRAPPER}} .wscts-for, {{WRAPPER}} .wscts-nav' => 'max-width: {{SIZE}}{{UNIT}}; margin-left:auto;margin-right:auto;']]);
        $this->add_responsive_control('container_alignment', [
            'label' => __('Alignment', 'ws-custom-testimonial-slider'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => ['title' => __('Left', 'ws-custom-testimonial-slider'), 'icon' => 'eicon-text-align-left'],
                'center' => ['title' => __('Center', 'ws-custom-testimonial-slider'), 'icon' => 'eicon-text-align-center'],
                'right' => ['title' => __('Right', 'ws-custom-testimonial-slider'), 'icon' => 'eicon-text-align-right'],
            ],
            'selectors' => ['{{WRAPPER}} .wscts-slider' => 'text-align: {{VALUE}};'],
        ]);
        $this->end_controls_section();

        // Navigation Style
        $this->start_controls_section('style_navigation', ['label' => __('Navigation Style', 'ws-custom-testimonial-slider'), 'tab' => Controls_Manager::TAB_STYLE]);
        $this->start_controls_tabs('nav_style_tabs');

        $this->start_controls_tab('nav_style_normal', ['label' => __('Normal', 'ws-custom-testimonial-slider')]);
        $this->add_control('nav_icon_color', ['label' => __('Icon Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-for .slick-arrow:before' => 'color: {{VALUE}}']]);
        $this->add_control('nav_bg_color', ['label' => __('Background Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-for .slick-arrow' => 'background: {{VALUE}}']]);
        $this->add_group_control(Group_Control_Border::get_type(), ['name' => 'nav_border', 'selector' => '{{WRAPPER}} .wscts-for .slick-arrow']);
        $this->add_responsive_control('nav_border_radius', ['label' => __('Border Radius', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-for .slick-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->add_responsive_control('nav_icon_size', ['label' => __('Icon Size', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','em','rem','custom'], 'selectors' => ['{{WRAPPER}} .wscts-for .slick-arrow:before' => 'font-size: {{SIZE}}{{UNIT}};']]);
        $this->add_responsive_control('nav_padding', ['label' => __('Padding', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-for .slick-arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->end_controls_tab();

        $this->start_controls_tab('nav_style_hover', ['label' => __('Hover', 'ws-custom-testimonial-slider')]);
        $this->add_control('nav_hover_icon_color', ['label' => __('Icon Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-for .slick-arrow:hover:before' => 'color: {{VALUE}}']]);
        $this->add_control('nav_hover_bg', ['label' => __('Background Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-for .slick-arrow:hover' => 'background: {{VALUE}}']]);
        $this->add_control('nav_hover_border_color', ['label' => __('Border Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-for .slick-arrow:hover' => 'border-color: {{VALUE}}']]);
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control('nav_custom_position', ['label' => __('Custom Position Enable', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SWITCHER, 'label_on' => __('Yes','ws-custom-testimonial-slider'),'label_off'=>__('No','ws-custom-testimonial-slider')]);
        $this->add_responsive_control('nav_prev_left', ['label' => __('Previous Left', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','%','em','rem','custom'], 'condition' => ['nav_custom_position!' => ''], 'selectors' => ['{{WRAPPER}} .wscts-for .slick-prev' => 'position: absolute; left: {{SIZE}}{{UNIT}};']]);
        $this->add_responsive_control('nav_prev_top', ['label' => __('Previous Top', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','%','em','rem','custom'], 'condition' => ['nav_custom_position!' => ''], 'selectors' => ['{{WRAPPER}} .wscts-for .slick-prev' => 'position: absolute; top: {{SIZE}}{{UNIT}};']]);
        $this->add_responsive_control('nav_next_right', ['label' => __('Next Right', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','%','em','rem','custom'], 'condition' => ['nav_custom_position!' => ''], 'selectors' => ['{{WRAPPER}} .wscts-for .slick-next' => 'position: absolute; right: {{SIZE}}{{UNIT}};']]);
        $this->add_responsive_control('nav_next_top', ['label' => __('Next Top', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','%','em','rem','custom'], 'condition' => ['nav_custom_position!' => ''], 'selectors' => ['{{WRAPPER}} .wscts-for .slick-next' => 'position: absolute; top: {{SIZE}}{{UNIT}};']]);
        $this->end_controls_section();

        // Dot Style
        $this->start_controls_section('style_dots', ['label' => __('Dot Style', 'ws-custom-testimonial-slider'), 'tab' => Controls_Manager::TAB_STYLE]);
        $this->start_controls_tabs('dots_style_tabs');
        $this->start_controls_tab('dots_style_normal', ['label' => __('Normal', 'ws-custom-testimonial-slider')]);
        $this->add_responsive_control('dot_size', ['label' => __('Dot Size', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};']]);
        $this->add_control('dot_color', ['label' => __('Dot Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-dot' => 'background: {{VALUE}}']]);
        $this->add_group_control(Group_Control_Border::get_type(), ['name' => 'dot_border', 'selector' => '{{WRAPPER}} .wscts-dot']);
        $this->add_responsive_control('dot_border_radius', ['label' => __('Border Radius', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-dot' => 'border-radius: {{SIZE}}{{UNIT}};']]);
        $this->end_controls_tab();

        $this->start_controls_tab('dots_style_active', ['label' => __('Active', 'ws-custom-testimonial-slider')]);
        $this->add_control('dot_active_color', ['label' => __('Active Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-dots .slick-dots li.slick-active .wscts-dot, {{WRAPPER}} .wscts-cube-dot-button.is-active .wscts-dot, {{WRAPPER}} .wscts-cards-dot-button.is-active .wscts-dot, {{WRAPPER}} .wscts-coverflow-dot-button.is-active .wscts-dot' => 'background: {{VALUE}}; border-color: {{VALUE}}']]);
        $this->add_responsive_control('dot_active_size', ['label' => __('Active Size', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-dots .slick-dots li.slick-active .wscts-dot, {{WRAPPER}} .wscts-cube-dot-button.is-active .wscts-dot, {{WRAPPER}} .wscts-cards-dot-button.is-active .wscts-dot, {{WRAPPER}} .wscts-coverflow-dot-button.is-active .wscts-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};']]);
        $this->end_controls_tab();

        $this->start_controls_tab('dots_style_hover', ['label' => __('Hover', 'ws-custom-testimonial-slider')]);
        $this->add_control('dot_hover_color', ['label' => __('Hover Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-dots .slick-dots li button:hover .wscts-dot, {{WRAPPER}} .wscts-cube-dot-button:hover .wscts-dot, {{WRAPPER}} .wscts-cards-dot-button:hover .wscts-dot, {{WRAPPER}} .wscts-coverflow-dot-button:hover .wscts-dot' => 'background: {{VALUE}}']]);
        $this->add_control('dot_hover_border_color', ['label' => __('Hover Border Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-dots .slick-dots li button:hover .wscts-dot, {{WRAPPER}} .wscts-cube-dot-button:hover .wscts-dot, {{WRAPPER}} .wscts-cards-dot-button:hover .wscts-dot, {{WRAPPER}} .wscts-coverflow-dot-button:hover .wscts-dot' => 'border-color: {{VALUE}}']]);
        $this->end_controls_tab();

        $this->end_controls_tabs();
        $this->add_responsive_control('dot_spacing', ['label' => __('Dot Spacing', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-dots .slick-dots li' => 'margin: 0 {{SIZE}}{{UNIT}};', '{{WRAPPER}} .wscts-cube-dots, {{WRAPPER}} .wscts-cards-dots, {{WRAPPER}} .wscts-coverflow-dots' => 'gap: {{SIZE}}{{UNIT}};']]);
        $this->add_responsive_control('dot_top_spacing', ['label' => __('Top Spacing', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-dots .slick-dots, {{WRAPPER}} .wscts-cube-dots, {{WRAPPER}} .wscts-cards-dots, {{WRAPPER}} .wscts-coverflow-dots' => 'margin-top: {{SIZE}}{{UNIT}};']]);
        $this->add_responsive_control('dot_bottom_spacing', ['label' => __('Bottom Spacing', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-dots .slick-dots, {{WRAPPER}} .wscts-cube-dots, {{WRAPPER}} .wscts-cards-dots, {{WRAPPER}} .wscts-coverflow-dots' => 'margin-bottom: {{SIZE}}{{UNIT}};']]);
        $this->end_controls_section();

        // Thumbnail Style
        $this->start_controls_section('style_thumbnail', ['label' => __('Thumbnail Style', 'ws-custom-testimonial-slider'), 'tab' => Controls_Manager::TAB_STYLE]);
        $this->add_group_control(Group_Control_Border::get_type(), ['name' => 'thumb_border', 'selector' => '{{WRAPPER}} .wscts-nav img']);
        $this->add_responsive_control('thumb_border_radius', ['label' => __('Border Radius', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-nav img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->add_responsive_control('thumb_padding', ['label' => __('Padding', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-nav img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->add_responsive_control('thumb_margin', ['label' => __('Margin', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-nav img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->add_responsive_control('thumb_opacity', ['label' => __('Opacity', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => [''], 'range' => ['px' => ['min'=>0,'max'=>1,'step'=>0.1]], 'selectors' => ['{{WRAPPER}} .wscts-nav img' => 'opacity: {{SIZE}};']]);
        $this->end_controls_section();

        // Social Icon Style
        $this->start_controls_section('style_social', ['label' => __('Social Icon Style', 'ws-custom-testimonial-slider'), 'tab' => Controls_Manager::TAB_STYLE]);
        $this->start_controls_tabs('social_style_tabs');
        $this->start_controls_tab('social_style_normal', ['label' => __('Normal', 'ws-custom-testimonial-slider')]);
        $this->add_control('social_icon_color', ['label' => __('Icon Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-socials a' => 'color: {{VALUE}}']]);
        $this->add_control('social_bg_color', ['label' => __('Background Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'default' => '#edf6ff', 'selectors' => ['{{WRAPPER}} .wscts-socials a' => 'background: {{VALUE}}']]);
        $this->add_group_control(Group_Control_Border::get_type(), ['name' => 'social_border', 'selector' => '{{WRAPPER}} .wscts-socials a']);
        $this->add_responsive_control('social_border_radius', ['label' => __('Border Radius', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-socials a' => 'border-radius: {{SIZE}}{{UNIT}};']]);
        $this->add_responsive_control('social_size', ['label' => __('Size', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-socials a' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};']]);
        $this->add_responsive_control('social_padding', ['label' => __('Padding', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-socials a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->add_responsive_control('social_spacing', ['label' => __('Spacing', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::SLIDER, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-socials a' => 'margin-right: {{SIZE}}{{UNIT}};']]);
        $this->end_controls_tab();
        $this->start_controls_tab('social_style_hover', ['label' => __('Hover', 'ws-custom-testimonial-slider')]);
        $this->add_control('social_hover_icon_color', ['label' => __('Icon Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'default' => '#ffffff', 'selectors' => ['{{WRAPPER}} .wscts-socials a:hover, {{WRAPPER}} .wscts-socials a:focus-visible' => 'color: {{VALUE}}']]);
        $this->add_control('social_hover_bg', ['label' => __('Background Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'default' => '#2f6ea5', 'selectors' => ['{{WRAPPER}} .wscts-socials a:hover, {{WRAPPER}} .wscts-socials a:focus-visible' => 'background: {{VALUE}}; background-color: {{VALUE}}']]);
        $this->add_control('social_hover_border_color', ['label' => __('Border Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-socials a:hover' => 'border-color: {{VALUE}}']]);
        $this->add_control('social_transform_scale', ['label' => __('Transform Scale', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::NUMBER, 'default' => 1, 'selectors' => ['{{WRAPPER}} .wscts-socials a:hover' => 'transform: scale({{VALUE}});']]);
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        

        // Content Style (Name, Designation, Content)
        $this->start_controls_section('style_content', ['label' => __('Content Style', 'ws-custom-testimonial-slider'), 'tab' => Controls_Manager::TAB_STYLE]);

        // Name
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'name_typography',
            'selector' => '{{WRAPPER}} .wscts-name',
        ]);
        $this->add_control('name_color', ['label' => __('Name Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-name' => 'color: {{VALUE}}']]);
        $this->add_responsive_control('name_margin', ['label' => __('Name Margin', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);

        // Designation
        $this->add_group_control(Group_Control_Typography::get_type(), ['name' => 'designation_typography', 'selector' => '{{WRAPPER}} .wscts-designation']);
        $this->add_control('designation_color', ['label' => __('Designation Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-designation' => 'color: {{VALUE}}']]);

        // Content
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'content_typography',
            'selector' => '{{WRAPPER}} .wscts-content',
        ]);
        $this->add_control('content_color', ['label' => __('Content Color', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::COLOR, 'selectors' => ['{{WRAPPER}} .wscts-content' => 'color: {{VALUE}}']]);

        $this->add_responsive_control('content_alignment', ['label' => __('Alignment', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::CHOOSE, 'options' => ['left' => ['title' => __('Left','ws-custom-testimonial-slider'),'icon'=>'eicon-text-align-left'], 'center' => ['title' => __('Center','ws-custom-testimonial-slider'),'icon'=>'eicon-text-align-center'], 'right' => ['title' => __('Right','ws-custom-testimonial-slider'),'icon'=>'eicon-text-align-right']], 'selectors' => ['{{WRAPPER}} .wscts-content, {{WRAPPER}} .wscts-name, {{WRAPPER}} .wscts-designation' => 'text-align: {{VALUE}};']]);

        $this->add_responsive_control('content_spacing', ['label' => __('Content Spacing', 'ws-custom-testimonial-slider'), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => ['px','em','rem','%','custom'], 'selectors' => ['{{WRAPPER}} .wscts-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);

        $this->end_controls_section();
    }

    protected function get_responsive_number(array $settings, string $key, string $device, int $default): int
    {
        $setting_key = 'desktop' === $device ? $key : $key . '_' . $device;
        $value = $settings[$setting_key] ?? null;

        if (is_array($settings[$key] ?? null)) {
            $value = $settings[$key][$device] ?? $settings[$key]['size'] ?? $value;
        }

        $value = absint($value);

        return max(1, min(10, $value ?: $default));
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $testimonials = get_posts([
            'post_type' => 'custom-testimonial',
            'posts_per_page' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
            'post_status' => 'publish',
            'suppress_filters' => false,
        ]);

        if (empty($testimonials)) {
            echo '<div class="wscts-empty">' . esc_html__('No testimonials found.', 'ws-custom-testimonial-slider') . '</div>';
            return;
        }

        Assets::enqueue_frontend();

        $uid = sanitize_html_class('wscts-' . $this->get_id());
        $thumbnail_position = in_array($settings['thumbnail_position'] ?? 'top', ['top', 'bottom'], true) ? $settings['thumbnail_position'] : 'top';
        $nav_type = in_array($settings['nav_type'] ?? 'both', ['arrows', 'dots', 'both', 'none'], true) ? $settings['nav_type'] : 'both';
        $effect = in_array($settings['effect'] ?? 'slide', ['slide', 'fade', 'cube', 'cards', 'coverflow'], true) ? $settings['effect'] : 'slide';
        $classes = [
            'wscts-slider',
            'wscts-thumbs-' . $thumbnail_position,
            'wscts-layout-' . $effect,
        ];

        if (! empty($settings['nav_custom_position'])) {
            $classes[] = 'wscts-custom-nav-position';
        }

        $data = [
            'slidesToShow' => [
                'desktop' => 5,
                'tablet' => 3,
                'mobile' => 1,
            ],
            'effect' => $effect,
            'arrows' => in_array($nav_type, ['arrows', 'both'], true),
            'dots' => in_array($nav_type, ['dots', 'both'], true),
            'autoplay' => ! empty($settings['enable_autoplay']),
            'autoplaySpeed' => max(100, absint($settings['autoplay_speed'] ?? 3000)),
            'speed' => max(100, absint($settings['transition_speed'] ?? 600)),
            'infinite' => true,
            'pauseOnHover' => true,
            'centerMode' => true,
        ];

        if ('cube' === $effect) {
            ?>
            <section class="<?php echo esc_attr(implode(' ', $classes)); ?>" id="<?php echo esc_attr($uid); ?>" data-settings="<?php echo esc_attr(wp_json_encode($data)); ?>">
                <div class="wscts-for wscts-cube" aria-roledescription="<?php esc_attr_e('carousel', 'ws-custom-testimonial-slider'); ?>">
                    <div class="wscts-cube-stage">
                        <?php foreach ($testimonials as $index => $testimonial) :
                            $post_id = $testimonial->ID;
                            $title = get_the_title($post_id);
                            $designation = get_post_meta($post_id, 'designation', true);
                            $socials = get_post_meta($post_id, 'social_icons', true);
                            $content = apply_filters( 'wscts_testimonial_content', wpautop( wp_kses_post( $testimonial->post_content ) ) );
                            $img = get_the_post_thumbnail_url($post_id, 'large');

                            if (! $img) {
                                $img = plugin_url('assets/images/demo/testimonial-' . (($index % 5) + 1) . '.jpg');
                            }
                            ?>
                            <article class="wscts-cube-slide<?php echo 0 === $index ? ' is-active' : ''; ?>" aria-hidden="<?php echo 0 === $index ? 'false' : 'true'; ?>">
                                <div class="wscts-cube-card">
                                    <div class="wscts-cube-image">
                                        <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($title); ?>" loading="lazy" decoding="async">
                                    </div>
                                    <div class="wscts-cube-body">
                                        <h4 class="wscts-name"><?php echo esc_html($title); ?></h4>

                                        <?php if ($designation) : ?>
                                            <p class="wscts-designation"><?php echo esc_html($designation); ?></p>
                                        <?php endif; ?>

                                        <div class="wscts-content"><?php echo wp_kses_post($content); ?></div>

                                        <?php if (is_array($socials) && $socials) : ?>
                                            <div class="wscts-socials">
                                                <?php foreach ($socials as $social) :
                                                    $icon = isset($social['icon']) ? sanitize_key($social['icon']) : 'website';
                                                    $url = isset($social['url']) ? esc_url($social['url']) : '';

                                                    if (! $url) {
                                                        continue;
                                                    }
                                                    ?>
                                                    <?php
                                                    /* translators: 1: social network name (e.g. twitter), 2: person's name */
                                                    ?>
                                                    <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( sprintf( __( 'Visit %1$s profile for %2$s', 'ws-custom-testimonial-slider' ), $icon, $title ) ); ?>">
                                                        <?php echo wp_kses( social_icon_html( $icon ), wscts_svg_kses_allowed() ); ?>
                                                    </a>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>

                    <?php if (in_array($nav_type, ['arrows', 'both'], true) && count($testimonials) > 1) : ?>
                        <button class="slick-arrow slick-prev wscts-cube-prev" type="button" aria-label="<?php esc_attr_e('Previous testimonial', 'ws-custom-testimonial-slider'); ?>"></button>
                        <button class="slick-arrow slick-next wscts-cube-next" type="button" aria-label="<?php esc_attr_e('Next testimonial', 'ws-custom-testimonial-slider'); ?>"></button>
                    <?php endif; ?>
                </div>

                <?php if (in_array($nav_type, ['dots', 'both'], true) && count($testimonials) > 1) : ?>
                    <div class="wscts-dots wscts-cube-dots" aria-label="<?php esc_attr_e('Testimonial pagination', 'ws-custom-testimonial-slider'); ?>"></div>
                <?php endif; ?>
            </section>
            <?php
            return;
        }

        if ('cards' === $effect) {
            ?>
            <section class="<?php echo esc_attr(implode(' ', $classes)); ?>" id="<?php echo esc_attr($uid); ?>" data-settings="<?php echo esc_attr(wp_json_encode($data)); ?>">
                <div class="wscts-for wscts-cards" aria-roledescription="<?php esc_attr_e('carousel', 'ws-custom-testimonial-slider'); ?>">
                    <div class="wscts-cards-stage">
                        <?php foreach ($testimonials as $index => $testimonial) :
                            $post_id = $testimonial->ID;
                            $title = get_the_title($post_id);
                            $designation = get_post_meta($post_id, 'designation', true);
                            $socials = get_post_meta($post_id, 'social_icons', true);
                            $content = apply_filters( 'wscts_testimonial_content', wpautop( wp_kses_post( $testimonial->post_content ) ) );
                            $img = get_the_post_thumbnail_url($post_id, 'large');

                            if (! $img) {
                                $img = plugin_url('assets/images/demo/testimonial-' . (($index % 5) + 1) . '.jpg');
                            }
                            ?>
                            <article class="wscts-card-slide<?php echo 0 === $index ? ' is-active' : ''; ?>" aria-hidden="<?php echo 0 === $index ? 'false' : 'true'; ?>">
                                <div class="wscts-card-effect-card">
                                    <div class="wscts-card-effect-image">
                                        <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($title); ?>" loading="lazy" decoding="async">
                                    </div>
                                    <div class="wscts-card-effect-bottom">
                                        <h4 class="wscts-name"><?php echo esc_html($title); ?></h4>

                                        <?php if ($designation) : ?>
                                            <p class="wscts-designation"><?php echo esc_html($designation); ?></p>
                                        <?php endif; ?>

                                        <div class="wscts-content"><?php echo wp_kses_post($content); ?></div>

                                        <?php if (is_array($socials) && $socials) : ?>
                                            <div class="wscts-socials">
                                                <?php foreach ($socials as $social) :
                                                    $icon = isset($social['icon']) ? sanitize_key($social['icon']) : 'website';
                                                    $url = isset($social['url']) ? esc_url($social['url']) : '';

                                                    if (! $url) {
                                                        continue;
                                                    }
                                                    ?>
                                                    <?php
                                                    /* translators: 1: social network name (e.g. twitter), 2: person's name */
                                                    ?>
                                                    <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( sprintf( __( 'Visit %1$s profile for %2$s', 'ws-custom-testimonial-slider' ), $icon, $title ) ); ?>">
                                                        <?php echo wp_kses( social_icon_html( $icon ), wscts_svg_kses_allowed() ); ?>
                                                    </a>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>

                    <?php if (count($testimonials) > 1) : ?>
                        <button class="slick-arrow slick-prev wscts-cards-prev" type="button" aria-label="<?php esc_attr_e('Previous testimonial', 'ws-custom-testimonial-slider'); ?>"></button>
                        <button class="slick-arrow slick-next wscts-cards-next" type="button" aria-label="<?php esc_attr_e('Next testimonial', 'ws-custom-testimonial-slider'); ?>"></button>
                    <?php endif; ?>
                </div>

                <?php if (in_array($nav_type, ['dots', 'both'], true) && count($testimonials) > 1) : ?>
                    <div class="wscts-dots wscts-cards-dots" aria-label="<?php esc_attr_e('Testimonial pagination', 'ws-custom-testimonial-slider'); ?>"></div>
                <?php endif; ?>
            </section>
            <?php
            return;
        }

        if ('coverflow' === $effect) {
            ?>
            <section class="<?php echo esc_attr(implode(' ', $classes)); ?>" id="<?php echo esc_attr($uid); ?>" data-settings="<?php echo esc_attr(wp_json_encode($data)); ?>">
                <div class="wscts-for wscts-coverflow" aria-roledescription="<?php esc_attr_e('carousel', 'ws-custom-testimonial-slider'); ?>">
                    <div class="wscts-coverflow-stage">
                        <?php foreach ($testimonials as $index => $testimonial) :
                            $post_id = $testimonial->ID;
                            $title = get_the_title($post_id);
                            $designation = get_post_meta($post_id, 'designation', true);
                            $socials = get_post_meta($post_id, 'social_icons', true);
                            $content = apply_filters( 'wscts_testimonial_content', wpautop( wp_kses_post( $testimonial->post_content ) ) );
                            $img = get_the_post_thumbnail_url($post_id, 'large');

                            if (! $img) {
                                $img = plugin_url('assets/images/demo/testimonial-' . (($index % 5) + 1) . '.jpg');
                            }
                            ?>
                            <article class="wscts-coverflow-slide<?php echo 0 === $index ? ' is-active' : ''; ?>" aria-hidden="<?php echo 0 === $index ? 'false' : 'true'; ?>">
                                <div class="wscts-coverflow-card">
                                    <div class="wscts-coverflow-image">
                                        <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($title); ?>" loading="lazy" decoding="async">
                                    </div>
                                    <div class="wscts-coverflow-body">
                                        <h4 class="wscts-name"><?php echo esc_html($title); ?></h4>

                                        <?php if ($designation) : ?>
                                            <p class="wscts-designation"><?php echo esc_html($designation); ?></p>
                                        <?php endif; ?>

                                        <div class="wscts-content"><?php echo wp_kses_post($content); ?></div>

                                        <?php if (is_array($socials) && $socials) : ?>
                                            <div class="wscts-socials">
                                                <?php foreach ($socials as $social) :
                                                    $icon = isset($social['icon']) ? sanitize_key($social['icon']) : 'website';
                                                    $url = isset($social['url']) ? esc_url($social['url']) : '';

                                                    if (! $url) {
                                                        continue;
                                                    }
                                                    ?>
                                                    <?php
                                                    /* translators: 1: social network name (e.g. twitter), 2: person's name */
                                                    ?>
                                                    <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( sprintf( __( 'Visit %1$s profile for %2$s', 'ws-custom-testimonial-slider' ), $icon, $title ) ); ?>">
                                                        <?php echo wp_kses( social_icon_html( $icon ), wscts_svg_kses_allowed() ); ?>
                                                    </a>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>

                    <?php if (count($testimonials) > 1) : ?>
                        <button class="slick-arrow slick-prev wscts-coverflow-prev" type="button" aria-label="<?php esc_attr_e('Previous testimonial', 'ws-custom-testimonial-slider'); ?>"></button>
                        <button class="slick-arrow slick-next wscts-coverflow-next" type="button" aria-label="<?php esc_attr_e('Next testimonial', 'ws-custom-testimonial-slider'); ?>"></button>
                    <?php endif; ?>
                </div>

                <?php if (in_array($nav_type, ['dots', 'both'], true) && count($testimonials) > 1) : ?>
                    <div class="wscts-dots wscts-coverflow-dots" aria-label="<?php esc_attr_e('Testimonial pagination', 'ws-custom-testimonial-slider'); ?>"></div>
                <?php endif; ?>
            </section>
            <?php
            return;
        }

        ?>
        <section class="<?php echo esc_attr(implode(' ', $classes)); ?>" id="<?php echo esc_attr($uid); ?>" data-settings="<?php echo esc_attr(wp_json_encode($data)); ?>">
            <div class="wscts-nav" aria-label="<?php esc_attr_e('Testimonial navigation', 'ws-custom-testimonial-slider'); ?>">
                <?php foreach ($testimonials as $index => $testimonial) :
                    $post_id = $testimonial->ID;
                    $title = get_the_title($post_id);
                    $img = get_the_post_thumbnail_url($post_id, 'thumbnail');

                    if (! $img) {
                        $img = plugin_url('assets/images/demo/testimonial-' . (($index % 5) + 1) . '.jpg');
                    }
                    ?>
                    <div class="wscts-nav-item">
                        <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($title); ?>" loading="lazy" decoding="async">
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="wscts-for">
                <?php foreach ($testimonials as $testimonial) :
                    $post_id = $testimonial->ID;
                    $title = get_the_title($post_id);
                    $designation = get_post_meta($post_id, 'designation', true);
                    $socials = get_post_meta($post_id, 'social_icons', true);
                    $content = apply_filters( 'wscts_testimonial_content', wpautop( wp_kses_post( $testimonial->post_content ) ) );
                    ?>
                    <div class="wscts-item">
                        <div class="wscts-content"><?php echo wp_kses_post($content); ?></div>
                        <h4 class="wscts-name"><?php echo esc_html($title); ?></h4>

                        <?php if ($designation) : ?>
                            <p class="wscts-designation"><?php echo esc_html($designation); ?></p>
                        <?php endif; ?>

                        <?php if (is_array($socials) && $socials) : ?>
                            <div class="wscts-socials">
                                <?php foreach ($socials as $social) :
                                    $icon = isset($social['icon']) ? sanitize_key($social['icon']) : 'website';
                                    $url = isset($social['url']) ? esc_url($social['url']) : '';

                                    if (! $url) {
                                        continue;
                                    }
                                    ?>
                                    <?php
                                    /* translators: 1: social network name (e.g. twitter), 2: person's name */
                                    ?>
                                    <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( sprintf( __( 'Visit %1$s profile for %2$s', 'ws-custom-testimonial-slider' ), $icon, $title ) ); ?>">
                                        <?php echo wp_kses( social_icon_html( $icon ), wscts_svg_kses_allowed() ); ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="wscts-dots" aria-label="<?php esc_attr_e('Testimonial pagination', 'ws-custom-testimonial-slider'); ?>"></div>
        </section>

        <?php
    }
}
