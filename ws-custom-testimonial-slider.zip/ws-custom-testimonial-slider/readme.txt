=== WS Custom Testimonial Slider ===

Contributors: WS
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A beautiful Elementor testimonial slider widget with Slide, Fade, Cube, Cards, and Coverflow effects, thumbnail navigation, and full style controls.

== Description ==

Adds a Custom Testimonial custom post type and an Elementor widget "Custom Testimonial Slider".

The widget renders published testimonial posts with a synchronized main slider and thumbnail navigation using local Slick assets. On first activation, the plugin seeds demo testimonials and attaches supported images from `assets/images/` as real Featured Images so the testimonial list is ready to preview.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`.
2. Activate Elementor for the Elementor widget editor experience.
3. Activate this plugin.
4. Edit a page with Elementor and insert the "Custom Testimonial Slider" widget.

== Elementor Requirement ==

Elementor is required to place and edit the slider widget. Plugin activation and testimonial seeding are allowed without Elementor so the custom post type and demo content can still be created.

== CPT Information ==

Post Type: Custom Testimonial
Slug: custom-testimonial
Supports: Title, Editor, Featured Image

On activation, the plugin enables Featured Image support for `custom-testimonial` without removing existing theme thumbnail support for other post types.

== Widget Usage ==

1. Add testimonials from **Custom Testimonials** in the WordPress admin.
2. Add a title, editor content, featured image, designation, and optional social links.
3. Edit a page with Elementor and add the **Custom Testimonial Slider** widget.
4. Use the widget controls to adjust thumbnail count, thumbnail position, effect, autoplay, navigation, dots, and style options.

Thumbnail navigation uses fixed visual sizing by default: the centered thumbnail is 100px by 100px, the adjacent previous/next thumbnails are 80px by 80px, and the outer visible thumbnails are 60px by 60px. Non-centered thumbnails render in grayscale.

Published Custom Testimonial posts are shown newest first.

== Security & Code Quality ==

- Direct file access is blocked with `ABSPATH` checks.
- Testimonial meta saves use nonce verification, autosave/revision guards, and `edit_post` capability checks.
- Admin inputs are sanitized before saving; social icons are restricted to an allowlist and social URLs are limited to `http`/`https`.
- Frontend output is escaped with WordPress escaping helpers.
- Social icons are inline SVG generated from a fixed allowlist, avoiding dependency on external icon fonts.
- Assets are registered centrally and enqueued only when the widget/admin screen needs them.
- Demo Featured Images are copied through WordPress media APIs and attached to seeded testimonial posts.

== Folder Structure ==

- `ws-custom-testimonial-slider.php` - plugin bootstrap and constants.
- `includes/class-plugin.php` - plugin coordinator and hook registration.
- `includes/class-activator.php` / `includes/class-deactivator.php` - activation, demo seeding, rewrite flushing, and deactivation handling.
- `includes/class-post-type.php` - `custom-testimonial` post type and Featured Image support.
- `includes/class-meta-boxes.php` - testimonial designation and social-link admin fields.
- `includes/class-assets.php` - central asset registration/enqueue logic.
- `includes/class-widgets.php` - Elementor widget registration.
- `includes/class-seeder.php` - one-time demo testimonial and demo thumbnail setup.
- `includes/helpers.php` - URL helpers, social icon allowlist, URL validation, and inline SVG output.
- `widgets/class-custom-testimonial-slider.php` - Elementor widget controls and frontend render template.
- `assets/css/` - frontend/editor/Slick styles.
- `assets/js/` - frontend/admin/Slick scripts.
- `assets/images/` - testimonial images for seeded Featured Images.
- `assets/images/demo/` - frontend fallback testimonial thumbnails.

== Frequently Asked Questions ==

= Why are social icons not showing? =

Use one of the supported icons in the testimonial meta box: facebook, instagram, linkedin, x, youtube, tiktok, or website. The plugin renders inline SVG icons, so Font Awesome is not required.

= How does center mode work? =

Thumbnail navigation uses center mode by default. The frontend script keeps the active Slick center slide highlighted and adds `sl-prev` / `sl-next` classes to the adjacent thumbnails for the responsive size treatment.

== Changelog ==

= 1.0.0 =
- Cleaned plugin architecture and asset loading.
- Hardened testimonial meta saving.
- Fixed thumbnail position rendering for top/bottom layouts.
- Added activation-time demo Featured Image attachment.
- Improved responsive slider UI, dot styling, social icons, arrow states, and center-mode behavior.
