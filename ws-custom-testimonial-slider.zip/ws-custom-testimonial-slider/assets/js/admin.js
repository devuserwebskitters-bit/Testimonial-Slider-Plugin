(function($) {
    'use strict';

    $(function() {
        var $table = $('#wscts_socials_table tbody');
        var nextIndex = 0;
        var config = window.wsctsAdmin || {};
        var icons = $.isArray(config.icons) && config.icons.length ? config.icons : [
            'facebook',
            'instagram',
            'linkedin',
            'x',
            'youtube',
            'tiktok',
            'website'
        ];
        var removeLabel = config.removeLabel || 'Remove';

        function escapeHtml(value) {
            return String(value).replace(/[&<>"']/g, function(character) {
                return {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#039;'
                }[character];
            });
        }

        function getIconOptions() {
            return icons.map(function(icon) {
                var safeIcon = escapeHtml(icon);

                return '<option value="' + safeIcon + '">' + safeIcon + '</option>';
            }).join('');
        }

        if (!$table.length) {
            return;
        }

        $table.find('[name^="wscts_socials["]').each(function() {
            var match = $(this).attr('name').match(/wscts_socials\[(\d+)\]/);

            if (match) {
                nextIndex = Math.max(nextIndex, parseInt(match[1], 10) + 1);
            }
        });

        $('#wscts_add_row').on('click', function(e) {
            e.preventDefault();

            var index = nextIndex;
            var row = '<tr>' +
                '<td><select name="wscts_socials[' + index + '][icon]">' +
                getIconOptions() +
                '</select></td>' +
                '<td><input type="url" name="wscts_socials[' + index + '][url]" class="widefat" /></td>' +
                '<td><button type="button" class="button wscts-remove-row">' + escapeHtml(removeLabel) + '</button></td>' +
                '</tr>';

            nextIndex++;
            $table.append(row);
        });

        $table.on('click', '.wscts-remove-row', function(e) {
            e.preventDefault();

            $(this).closest('tr').remove();
        });
    });
})(jQuery);
