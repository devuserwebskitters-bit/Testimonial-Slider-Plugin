(function($) {
    'use strict';

    var DEFAULTS = {
        slidesToShow: {
            desktop: 5,
            tablet: 3,
            mobile: 1
        },
        effect: 'slide',
        arrows: true,
        dots: true,
        autoplay: true,
        autoplaySpeed: 3000,
        speed: 600,
        infinite: true,
        pauseOnHover: true,
        centerMode: true
    };

    function clamp(value, min, max) {
        value = parseInt(value, 10);

        if (isNaN(value)) {
            value = min;
        }

        return Math.max(min, Math.min(value, max));
    }

    function getSettings($section) {
        var raw = $section.attr('data-settings');
        var settings = {};

        if (raw) {
            try {
                settings = JSON.parse(raw);
            } catch (error) {
                settings = {};
            }
        }

        return $.extend(true, {}, DEFAULTS, settings);
    }

    function getSlidesToShow(settings, device, totalSlides) {
        var configured = settings.slidesToShow && settings.slidesToShow[device];
        var maxSlides = Math.max(totalSlides, 1);
        var slidesToShow;

        slidesToShow = clamp(configured, 1, maxSlides);

        if (settings.centerMode && slidesToShow > 1 && slidesToShow % 2 === 0) {
            slidesToShow -= 1;
        }

        return Math.max(slidesToShow, 1);
    }

    function prepareNavItems($sliderNav, visibleSlides) {
        var $originalItems = $sliderNav.children();
        var originalCount = $originalItems.length;

        $originalItems.each(function(index) {
            $(this).attr('data-wscts-index', index);
        });

        if (originalCount > 1 && originalCount <= visibleSlides) {
            $originalItems.clone(false).each(function(index) {
                $(this).attr('data-wscts-index', index);
            }).appendTo($sliderNav);
        }

        $sliderNav.data('wsctsOriginalCount', originalCount);

        return originalCount;
    }

    function updateSlickClasses($sliderNav) {
        var $centerSlide;

        $sliderNav.find('.slick-slide').removeClass('sl-next sl-prev');

        $centerSlide = $sliderNav.find('.slick-slide.slick-active.slick-center').first();

        if (!$centerSlide.length) {
            return;
        }

        $centerSlide.prev('.slick-slide').addClass('sl-prev');
        $centerSlide.next('.slick-slide').addClass('sl-next');
    }

    function initSlider($section) {
        var settings = getSettings($section);

        if (settings.effect === 'cube') {
            initCubeSlider($section, settings);
            return;
        }

        if (settings.effect === 'cards') {
            initCardsSlider($section, settings);
            return;
        }

        if (settings.effect === 'coverflow') {
            initCoverflowSlider($section, settings);
            return;
        }

        var $sliderFor = $section.find('.wscts-for').first();
        var $sliderNav = $section.find('.wscts-nav').first();
        var $sliderDots = $section.find('.wscts-dots').first();
        var navCount = $sliderNav.children().length;
        var mainCount = $sliderFor.children().length;
        var hasNav = $sliderNav.length && navCount > 1;
        var desktopSlides = getSlidesToShow(settings, 'desktop', navCount);
        var tabletSlides = getSlidesToShow(settings, 'tablet', navCount);
        var mobileSlides = getSlidesToShow(settings, 'mobile', navCount);

        if (!$sliderFor.length || !$.fn.slick) {
            return;
        }

        if ($sliderFor.hasClass('slick-initialized')) {
            return;
        }

        if (hasNav) {
            navCount = prepareNavItems($sliderNav, Math.max(desktopSlides, tabletSlides, mobileSlides));
        }

        $sliderFor.slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: settings.arrows && mainCount > 1,
            dots: settings.dots && mainCount > 1,
            customPaging: function(slider, index) {
                return '<button type="button" aria-label="Go to testimonial ' + (index + 1) + '"><span class="wscts-dot"></span></button>';
            },
            appendDots: $sliderDots.length ? $sliderDots : $sliderFor,
            fade: settings.effect === 'fade',
            asNavFor: hasNav ? $sliderNav : null,
            autoplay: settings.autoplay && mainCount > 1,
            autoplaySpeed: parseInt(settings.autoplaySpeed, 10) || DEFAULTS.autoplaySpeed,
            speed: parseInt(settings.speed, 10) || DEFAULTS.speed,
            infinite: settings.infinite && mainCount > 1,
            pauseOnHover: settings.pauseOnHover,
            adaptiveHeight: true
        });

        if (!hasNav || $sliderNav.hasClass('slick-initialized')) {
            return;
        }

        $sliderNav.on('init afterChange reInit setPosition', function() {
            updateSlickClasses($sliderNav);
        });

        $sliderNav.on('click', '.wscts-nav-item', function() {
            var index = parseInt($(this).attr('data-wscts-index'), 10);

            if (!isNaN(index)) {
                $sliderFor.slick('slickGoTo', index);
            }
        });

        $sliderNav.slick({
            slidesToShow: desktopSlides,
            slidesToScroll: 1,
            asNavFor: $sliderFor,
            dots: false,
            arrows: false,
            centerMode: settings.centerMode && navCount > 1,
            focusOnSelect: false,
            centerPadding: '0',
            infinite: settings.infinite && navCount > 1,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: tabletSlides,
                        centerMode: settings.centerMode && navCount > 1,
                        infinite: settings.infinite && navCount > 1
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: mobileSlides,
                        centerMode: settings.centerMode && navCount > 1,
                        infinite: settings.infinite && navCount > 1
                    }
                }
            ]
        });
    }

    function initCubeSlider($section, settings) {
        var $cube = $section.find('.wscts-cube').first();
        var $stage = $cube.find('.wscts-cube-stage').first();
        var $slides = $stage.children('.wscts-cube-slide');
        var $dotsWrap = $section.find('.wscts-cube-dots').first();
        var total = $slides.length;
        var index = 0;
        var autoplayTimer = null;
        var speed = parseInt(settings.speed, 10) || DEFAULTS.speed;

        if (!$cube.length || !$stage.length || !total || $cube.data('wsctsCubeInitialized')) {
            return;
        }

        $cube.data('wsctsCubeInitialized', true);
        $stage.css('transition-duration', speed + 'ms');
        $slides.css('transition-duration', speed + 'ms, 300ms');

        function setStageHeight() {
            var $active = $slides.eq(index);
            var height = $active.find('.wscts-cube-card').outerHeight(true) || 0;

            if (height) {
                $stage.css('height', height + 'px');
            }
        }

        function renderDots() {
            var html = '';

            if (!$dotsWrap.length || total < 2) {
                return;
            }

            for (var i = 0; i < total; i += 1) {
                html += '<button type="button" class="wscts-cube-dot-button" data-wscts-cube-index="' + i + '" aria-label="Go to testimonial ' + (i + 1) + '"><span class="wscts-dot"></span></button>';
            }

            $dotsWrap.html(html);
        }

        function updateDots() {
            if (!$dotsWrap.length) {
                return;
            }

            $dotsWrap.find('.wscts-cube-dot-button')
                .removeClass('is-active')
                .attr('aria-current', 'false')
                .eq(index)
                .addClass('is-active')
                .attr('aria-current', 'true');
        }

        function updateSlides() {
            var depth = Math.max(160, Math.min($stage.outerWidth(), $stage.outerHeight() || 520) / 2);

            $slides.each(function(slideIndex) {
                var offset = slideIndex - index;
                var normalized = offset;

                if (normalized > total / 2) {
                    normalized -= total;
                } else if (normalized < -total / 2) {
                    normalized += total;
                }

                $(this)
                    .toggleClass('is-active', slideIndex === index)
                    .attr('aria-hidden', slideIndex === index ? 'false' : 'true')
                    .css({
                        opacity: Math.abs(normalized) <= 1 ? 1 : 0,
                        pointerEvents: slideIndex === index ? 'auto' : 'none',
                        transform: 'rotateY(' + (normalized * 90) + 'deg) translateZ(' + depth + 'px)',
                        zIndex: 10 - Math.abs(normalized)
                    });
            });

            $stage.css('transform', 'translateZ(-' + depth + 'px)');
            setStageHeight();
            updateDots();
        }

        function goTo(nextIndex) {
            index = (nextIndex + total) % total;
            updateSlides();
        }

        function stopAutoplay() {
            if (autoplayTimer) {
                window.clearInterval(autoplayTimer);
                autoplayTimer = null;
            }
        }

        function startAutoplay() {
            stopAutoplay();

            if (settings.autoplay && total > 1) {
                autoplayTimer = window.setInterval(function() {
                    goTo(index + 1);
                }, parseInt(settings.autoplaySpeed, 10) || DEFAULTS.autoplaySpeed);
            }
        }

        renderDots();
        updateSlides();
        startAutoplay();

        $cube.on('click', '.wscts-cube-prev', function() {
            goTo(index - 1);
            startAutoplay();
        });

        $cube.on('click', '.wscts-cube-next', function() {
            goTo(index + 1);
            startAutoplay();
        });

        $dotsWrap.on('click', '.wscts-cube-dot-button', function() {
            var nextIndex = parseInt($(this).attr('data-wscts-cube-index'), 10);

            if (!isNaN(nextIndex)) {
                goTo(nextIndex);
                startAutoplay();
            }
        });

        if (settings.pauseOnHover) {
            $section.on('mouseenter', stopAutoplay);
            $section.on('mouseleave', startAutoplay);
        }

        $(window).on('resize', function() {
            updateSlides();
        });
    }

    function initCardsSlider($section, settings) {
        var $cards = $section.find('.wscts-cards').first();
        var $stage = $cards.find('.wscts-cards-stage').first();
        var $slides = $stage.children('.wscts-card-slide');
        var $dotsWrap = $section.find('.wscts-cards-dots').first();
        var total = $slides.length;
        var index = Math.min(2, Math.max(total - 1, 0));
        var autoplayTimer = null;
        var speed = parseInt(settings.speed, 10) || 500;
        var wheelLocked = false;

        if (!$cards.length || !$stage.length || !total || $cards.data('wsctsCardsInitialized')) {
            return;
        }

        $cards.data('wsctsCardsInitialized', true);
        $slides.css('transition-duration', speed + 'ms');

        function renderDots() {
            var html = '';

            if (!$dotsWrap.length || total < 2) {
                return;
            }

            for (var i = 0; i < total; i += 1) {
                html += '<button type="button" class="wscts-cards-dot-button" data-wscts-cards-index="' + i + '" aria-label="Go to testimonial ' + (i + 1) + '"><span class="wscts-dot"></span></button>';
            }

            $dotsWrap.html(html);
        }

        function updateDots() {
            if (!$dotsWrap.length) {
                return;
            }

            $dotsWrap.find('.wscts-cards-dot-button')
                .removeClass('is-active')
                .attr('aria-current', 'false')
                .eq(index)
                .addClass('is-active')
                .attr('aria-current', 'true');
        }

        function setStageHeight() {
            var height = $slides.eq(index).find('.wscts-card-effect-card').outerHeight(true) || 0;

            if (height) {
                $stage.css('height', height + 'px');
            }
        }

        function updateSlides() {
            $slides.each(function(slideIndex) {
                var offset = slideIndex - index;

                if (offset > total / 2) {
                    offset -= total;
                } else if (offset < -total / 2) {
                    offset += total;
                }

                $(this)
                    .toggleClass('is-active', slideIndex === index)
                    .attr('aria-hidden', slideIndex === index ? 'false' : 'true')
                    .css({
                        opacity: Math.abs(offset) > 3 ? 0 : 1,
                        pointerEvents: slideIndex === index ? 'auto' : 'none',
                        transform: 'translateX(' + (offset * 34) + 'px) translateY(' + (Math.abs(offset) * 12) + 'px) rotate(' + (offset * 7) + 'deg) scale(' + (1 - Math.min(Math.abs(offset) * 0.06, 0.18)) + ')',
                        zIndex: 20 - Math.abs(offset)
                    });
            });

            setStageHeight();
            updateDots();
        }

        function goTo(nextIndex) {
            index = (nextIndex + total) % total;
            updateSlides();
        }

        function stopAutoplay() {
            if (autoplayTimer) {
                window.clearInterval(autoplayTimer);
                autoplayTimer = null;
            }
        }

        function startAutoplay() {
            stopAutoplay();

            if (settings.autoplay && total > 1) {
                autoplayTimer = window.setInterval(function() {
                    goTo(index + 1);
                }, parseInt(settings.autoplaySpeed, 10) || DEFAULTS.autoplaySpeed);
            }
        }

        renderDots();
        updateSlides();
        startAutoplay();

        $cards.on('click', '.wscts-cards-prev', function() {
            goTo(index - 1);
            startAutoplay();
        });

        $cards.on('click', '.wscts-cards-next', function() {
            goTo(index + 1);
            startAutoplay();
        });

        $dotsWrap.on('click', '.wscts-cards-dot-button', function() {
            var nextIndex = parseInt($(this).attr('data-wscts-cards-index'), 10);

            if (!isNaN(nextIndex)) {
                goTo(nextIndex);
                startAutoplay();
            }
        });

        $cards.on('wheel', function(event) {
            if (total < 2 || wheelLocked) {
                return;
            }

            event.preventDefault();
            wheelLocked = true;
            goTo(index + (event.originalEvent.deltaY > 0 ? 1 : -1));
            startAutoplay();
            window.setTimeout(function() {
                wheelLocked = false;
            }, speed);
        });

        if (settings.pauseOnHover) {
            $section.on('mouseenter', stopAutoplay);
            $section.on('mouseleave', startAutoplay);
        }

        $(window).on('resize', function() {
            setStageHeight();
        });
    }

    function initCoverflowSlider($section, settings) {
        var $coverflow = $section.find('.wscts-coverflow').first();
        var $stage = $coverflow.find('.wscts-coverflow-stage').first();
        var $slides = $stage.children('.wscts-coverflow-slide');
        var $dotsWrap = $section.find('.wscts-coverflow-dots').first();
        var total = $slides.length;
        var index = 0;
        var autoplayTimer = null;
        var speed = parseInt(settings.speed, 10) || DEFAULTS.speed;
        var isDragging = false;
        var dragStartX = 0;
        var dragDelta = 0;
        var DRAG_THRESHOLD = 50;

        if (!$coverflow.length || !$stage.length || !total || $coverflow.data('wsctsCoverflowInitialized')) {
            return;
        }

        $coverflow.data('wsctsCoverflowInitialized', true);
        $slides.css('transition-duration', speed + 'ms');

        function renderDots() {
            var html = '';

            if (!$dotsWrap.length || total < 2) {
                return;
            }

            for (var i = 0; i < total; i += 1) {
                html += '<button type="button" class="wscts-coverflow-dot-button" data-wscts-coverflow-index="' + i + '" aria-label="Go to testimonial ' + (i + 1) + '"><span class="wscts-dot"></span></button>';
            }

            $dotsWrap.html(html);
        }

        function updateDots() {
            if (!$dotsWrap.length) {
                return;
            }

            $dotsWrap.find('.wscts-coverflow-dot-button')
                .removeClass('is-active')
                .attr('aria-current', 'false')
                .eq(index)
                .addClass('is-active')
                .attr('aria-current', 'true');
        }

        function setStageHeight() {
            var height = $slides.eq(index).find('.wscts-coverflow-card').outerHeight(true) || 0;

            if (height) {
                $stage.css('height', height + 'px');
            }
        }

        function updateSlides() {
            $slides.each(function(slideIndex) {
                var offset = slideIndex - index;

                // Wrap offset for infinite feel
                if (offset > total / 2) {
                    offset -= total;
                } else if (offset < -total / 2) {
                    offset += total;
                }

                var absOffset = Math.abs(offset);
                var rotateY = offset * 45;       // degrees of Y-axis rotation per step
                var translateX = offset * 55;    // percentage lateral shift per step
                var translateZ = absOffset > 0 ? -120 * absOffset : 0; // push non-center back
                var scale = absOffset === 0 ? 1 : Math.max(0.72 - (absOffset - 1) * 0.08, 0.56);
                var opacity = absOffset > 2 ? 0 : (absOffset === 0 ? 1 : 0.65 - (absOffset - 1) * 0.15);
                var zIndex = 20 - absOffset;

                $(this)
                    .toggleClass('is-active', slideIndex === index)
                    .attr('aria-hidden', slideIndex === index ? 'false' : 'true')
                    .css({
                        transform: 'translateX(' + translateX + '%) translateZ(' + translateZ + 'px) rotateY(' + rotateY + 'deg) scale(' + scale + ')',
                        opacity: Math.max(opacity, 0),
                        zIndex: zIndex,
                        pointerEvents: slideIndex === index ? 'auto' : 'none'
                    });
            });

            setStageHeight();
            updateDots();
        }

        function goTo(nextIndex) {
            index = (nextIndex + total) % total;
            updateSlides();
        }

        function stopAutoplay() {
            if (autoplayTimer) {
                window.clearInterval(autoplayTimer);
                autoplayTimer = null;
            }
        }

        function startAutoplay() {
            stopAutoplay();

            if (settings.autoplay && total > 1) {
                autoplayTimer = window.setInterval(function() {
                    goTo(index + 1);
                }, parseInt(settings.autoplaySpeed, 10) || DEFAULTS.autoplaySpeed);
            }
        }

        renderDots();
        updateSlides();
        startAutoplay();

        $coverflow.on('click', '.wscts-coverflow-prev', function() {
            goTo(index - 1);
            startAutoplay();
        });

        $coverflow.on('click', '.wscts-coverflow-next', function() {
            goTo(index + 1);
            startAutoplay();
        });

        // Click on a non-active visible slide to navigate to it
        $stage.on('click', '.wscts-coverflow-slide:not(.is-active)', function() {
            var slideIndex = $slides.index(this);

            if (slideIndex !== -1) {
                goTo(slideIndex);
                startAutoplay();
            }
        });

        $dotsWrap.on('click', '.wscts-coverflow-dot-button', function() {
            var nextIndex = parseInt($(this).attr('data-wscts-coverflow-index'), 10);

            if (!isNaN(nextIndex)) {
                goTo(nextIndex);
                startAutoplay();
            }
        });

        // Touch/drag support
        $stage.on('mousedown touchstart', function(e) {
            isDragging = true;
            dragDelta = 0;
            dragStartX = e.type === 'touchstart' ? e.originalEvent.touches[0].clientX : e.clientX;
            stopAutoplay();
        });

        $(document).on('mousemove touchmove', function(e) {
            if (!isDragging) {
                return;
            }

            var currentX = e.type === 'touchmove' ? e.originalEvent.touches[0].clientX : e.clientX;
            dragDelta = currentX - dragStartX;
        });

        $(document).on('mouseup touchend', function() {
            if (!isDragging) {
                return;
            }

            isDragging = false;

            if (Math.abs(dragDelta) >= DRAG_THRESHOLD) {
                goTo(dragDelta < 0 ? index + 1 : index - 1);
            }

            startAutoplay();
        });

        if (settings.pauseOnHover) {
            $section.on('mouseenter', stopAutoplay);
            $section.on('mouseleave', startAutoplay);
        }

        $(window).on('resize', function() {
            setStageHeight();
        });
    }

    function initScope($scope) {
        var $sliders = $scope.hasClass('wscts-slider') ? $scope : $scope.find('.wscts-slider');

        $sliders.each(function() {
            initSlider($(this));
        });
    }

    $(function() {
        initScope($(document));
    });

    $(window).on('elementor/frontend/init', function() {
        if (!window.elementorFrontend || !window.elementorFrontend.hooks) {
            return;
        }

        window.elementorFrontend.hooks.addAction(
            'frontend/element_ready/custom_testimonial_slider.default',
            function($scope) {
                initScope($scope);
            }
        );
    });
})(jQuery);
