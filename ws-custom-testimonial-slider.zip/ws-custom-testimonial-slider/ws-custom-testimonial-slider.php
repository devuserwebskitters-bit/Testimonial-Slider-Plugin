<?php
/**
 * Plugin Name: WS Custom Testimonial Slider
 * Plugin URI:  https://devuserwebskitters.com/
 * Description: Custom testimonial slider Elementor widget.
 * Version:     1.0.0
 * Author:      Bipra Santra
 * Text Domain: ws-custom-testimonial-slider
 * Requires at least: 6.5
 * Tested up to: 6.8
 * Requires PHP: 8.0
 * Requires Plugins: elementor
 * License:     GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * @package WSCTS
 */

namespace WSCTS;

if (! defined('ABSPATH')) {
    exit;
}

if (! defined('WSCTS_VERSION')) {
    define('WSCTS_VERSION', '1.0.0');
}

if (! defined('WSCTS_FILE')) {
    define('WSCTS_FILE', __FILE__);
}

if (! defined('WSCTS_PATH')) {
    define('WSCTS_PATH', plugin_dir_path(__FILE__));
}

if (! defined('WSCTS_URL')) {
    define('WSCTS_URL', plugin_dir_url(__FILE__));
}

require_once __DIR__ . '/includes/class-plugin.php';

function wscts_run_plugin(): void
{
    $plugin = new Plugin(__FILE__);
    $plugin->run();
}

wscts_run_plugin();
