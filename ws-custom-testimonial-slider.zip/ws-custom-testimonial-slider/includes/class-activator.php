<?php

namespace WSCTS;

if (! defined('ABSPATH')) {
    exit;
}

class Activator
{
    public static function activate(): void
    {
        // Elementor is needed only for the Elementor widget editor/UI.
        // Do not block plugin activation so we can seed demo content (custom-testimonial posts).

        Post_Type::support_featured_images();
        Post_Type::register_post_type();

        require_once __DIR__ . '/class-seeder.php';
        Seeder::seed_dummy_testimonials();
        Seeder::attach_demo_thumbnails_to_existing();

        flush_rewrite_rules();
    }
}
