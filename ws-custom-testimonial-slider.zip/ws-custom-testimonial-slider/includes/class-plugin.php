<?php

namespace WSCTS;

if (! defined('ABSPATH')) {
    exit;
}

class Plugin
{
    protected string $file;

    public function __construct(string $file)
    {
        $this->file = $file;
    }

    public function run(): void
    {
        register_activation_hook($this->file, [Activator::class, 'activate']);
        register_deactivation_hook($this->file, [Deactivator::class, 'deactivate']);

        add_action('admin_init', [$this, 'check_elementor_active']);

        // Ensure demo/test content thumbnails are attached even if activation hooks were missed
        // or demo import happened after the initial seeding.
        add_action('admin_init', [$this, 'ensure_demo_thumbnails']);

        // Make sure Seeder is available for admin fallback thumbnail attachment.
        require_once __DIR__ . '/class-seeder.php';


        $this->includes();
    }

    protected function includes(): void
    {
        require_once __DIR__ . '/class-activator.php';
        require_once __DIR__ . '/class-deactivator.php';
        require_once __DIR__ . '/class-post-type.php';
        require_once __DIR__ . '/class-meta-boxes.php';
        require_once __DIR__ . '/class-assets.php';
        require_once __DIR__ . '/class-widgets.php';
        require_once __DIR__ . '/helpers.php';

        Post_Type::register();
        Meta_Boxes::init();
        Assets::init();
        Widgets::init();
    }

    public function check_elementor_active(): void
    {
        if (! is_admin()) {
            return;
        }

        if (! current_user_can('activate_plugins') || class_exists('\\Elementor\\Plugin')) {
            return;
        }

        if (! function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        if (is_plugin_active(plugin_basename($this->file))) {
            // Elementor is required for the Elementor widget UI.
            // This plugin should not block/disable itself when Elementor is not active,
            // and it should not show admin notices in that case.
        }
    }

    public function ensure_demo_thumbnails(): void
    {
        // Only run in admin; demo import usually happens there.
        if (! is_admin()) {
            return;
        }

        // Avoid running on every admin request.
        $already = (int) get_option('wscts_demo_thumbs_ensured_v1', 0);
        if ($already === 1) {
            return;
        }

        // If demo content exists, attach thumbnails that are missing.
        if (post_type_exists('custom-testimonial')) {
            // Seeder::attach_demo_thumbnails_to_existing() checks for existing thumbnails.
            Seeder::attach_demo_thumbnails_to_existing();
        }

        update_option('wscts_demo_thumbs_ensured_v1', 1, false);
    }
}

