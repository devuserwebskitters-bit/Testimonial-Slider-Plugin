<?php

namespace WSCTS;

if (! defined('ABSPATH')) {
    exit;
}

class Post_Type
{
    public static function register(): void
    {
        add_action('after_setup_theme', [self::class, 'support_featured_images']);
        add_action('init', [self::class, 'register_post_type']);
    }

    public static function support_featured_images(): void
    {
        global $_wp_theme_features;

        if (current_theme_supports('post-thumbnails', 'custom-testimonial')) {
            return;
        }

        if (current_theme_supports('post-thumbnails')) {
            $supported_post_types = $_wp_theme_features['post-thumbnails'][0] ?? true;

            if (true === $supported_post_types) {
                return;
            }

            if (is_array($supported_post_types)) {
                $supported_post_types[] = 'custom-testimonial';
                add_theme_support('post-thumbnails', array_values(array_unique($supported_post_types)));

                return;
            }
        }

        add_theme_support('post-thumbnails', ['custom-testimonial']);
    }

    public static function register_post_type(): void
    {
        $labels = [
            'name' => __('Custom Testimonials', 'ws-custom-testimonial-slider'),
            'singular_name' => __('Custom Testimonial', 'ws-custom-testimonial-slider'),
        ];

        $args = [
            'labels' => $labels,
            'public' => true,
            'has_archive' => false,
            'show_in_rest' => true,
            'supports' => ['title', 'editor', 'thumbnail'],
            'menu_icon' => 'dashicons-testimonial',
            'rewrite' => ['slug' => 'custom-testimonial'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ];

        register_post_type('custom-testimonial', $args);
    }
}
