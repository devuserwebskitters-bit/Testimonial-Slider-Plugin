<?php

namespace WSCTS;

if (! defined('ABSPATH')) {
    exit;
}

class Deactivator
{
    public static function deactivate(): void
    {
        // Nothing special for now
        flush_rewrite_rules();
    }
}
