<?php

namespace WSCTS;

if (! defined('ABSPATH')) {
    exit;
}

class Assets
{
    public static function init(): void
    {
        add_action('wp_enqueue_scripts', [self::class, 'register_assets']);
        add_action('elementor/frontend/after_register_styles', [self::class, 'register_assets']);
        add_action('elementor/frontend/after_register_scripts', [self::class, 'register_assets']);
        add_action('elementor/editor/after_enqueue_styles', [self::class, 'enqueue_editor_styles']);
        add_action('elementor/editor/after_enqueue_scripts', [self::class, 'enqueue_editor_scripts']);
    }

    public static function register_assets(): void
    {
        wp_register_style('slick-css', WSCTS_URL . 'assets/css/slick.css', [], '1.8.1');
        wp_register_style('slick-theme-css', WSCTS_URL . 'assets/css/slick-theme.css', ['slick-css'], '1.8.1');
        wp_register_style('wscts-frontend', WSCTS_URL . 'assets/css/frontend.css', ['slick-theme-css'], WSCTS_VERSION);
        wp_register_style('wscts-editor', WSCTS_URL . 'assets/css/editor.css', ['wscts-frontend'], WSCTS_VERSION);

        wp_register_script('slick-js', WSCTS_URL . 'assets/js/slick.min.js', ['jquery'], '1.8.1', true);
        wp_register_script('wscts-frontend', WSCTS_URL . 'assets/js/frontend.js', ['jquery', 'slick-js'], WSCTS_VERSION, true);
    }

    public static function enqueue_editor_styles(): void
    {
        self::register_assets();

        wp_enqueue_style('wscts-editor');
    }

    public static function enqueue_editor_scripts(): void
    {
        self::register_assets();

        wp_enqueue_script('wscts-frontend');
    }

    public static function enqueue_frontend(): void
    {
        self::register_assets();

        wp_enqueue_style('wscts-frontend');
        wp_enqueue_script('wscts-frontend');
    }
}
