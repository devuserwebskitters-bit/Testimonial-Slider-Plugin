<?php

namespace WSCTS;

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Security class for handling security headers, logging, and validation
 *
 * Implements:
 * - Security headers (X-Content-Type-Options, X-Frame-Options, etc.)
 * - Security event logging
 * - Form field validation (designation, social URL, icons)
 * - REST API security checks
 *
 * @package WSCTS
 */
class Security
{
    /**
     * Initialize security hooks
     */
    public static function init(): void
    {
        // Security headers
        add_action('send_headers', [self::class, 'set_security_headers']);
        
        // Block direct access to plugin files
        add_action('init', [self::class, 'block_direct_access']);
    }

    /**
     * Set security headers for the application
     * 
     * Headers added:
     * - X-UA-Compatible: IE=edge
     * - X-Content-Type-Options: nosniff
     * - X-Frame-Options: SAMEORIGIN
     * - X-XSS-Protection: 1; mode=block
     * - Referrer-Policy: strict-origin-when-cross-origin
     */
    public static function set_security_headers(): void
    {
        if (is_admin()) {
            // X-UA-Compatible header for IE compatibility
            header('X-UA-Compatible: IE=edge', true);
            
            // X-Content-Type-Options prevents MIME type sniffing
            header('X-Content-Type-Options: nosniff', true);
            
            // X-Frame-Options prevents clickjacking
            header('X-Frame-Options: SAMEORIGIN', true);
            
            // X-XSS-Protection for older browsers
            header('X-XSS-Protection: 1; mode=block', true);
            
            // Referrer-Policy for privacy
            header('Referrer-Policy: strict-origin-when-cross-origin', true);
        }
    }

    /**
     * Block direct access to plugin files
     */
    public static function block_direct_access(): void
    {
        // Check if someone is accessing plugin files directly
        $request_uri = sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'] ?? ''));
        $plugin_path = basename(WSCTS_PATH);
        
        if (strpos($request_uri, $plugin_path) !== false && basename($request_uri) === $plugin_path) {
            status_header(403);
            wp_die(
                esc_html__('Direct access not permitted.', 'ws-custom-testimonial-slider'),
                esc_html__('Access Denied', 'ws-custom-testimonial-slider'),
                ['response' => 403]
            );
        }
    }

    /**
     * Log security events
     * Kept as a stub — use a proper logging plugin for production event tracking.
     *
     * @param string $event   Event name/message
     * @param array  $context Additional context data
     * @return void
     */
    public static function log_event(string $event, array $context = []): void
    {
        // error_log() intentionally omitted; hook into a logging plugin if needed.
    }

    /**
     * Validate designation field
     * 
     * Rules:
     * - Max 100 characters
     * - No script tags or dangerous patterns
     * - Trimmed of whitespace
     *
     * @param string $designation The designation text
     * @return array ['valid' => bool, 'value' => string, 'error' => string|null]
     */
    public static function validate_designation(string $designation): array
    {
        $designation = trim($designation);

        // Check if empty (empty is valid)
        if (empty($designation)) {
            return [
                'valid' => true,
                'value' => '',
                'error' => null,
            ];
        }

        // Check length (max 100 characters)
        if (strlen($designation) > 100) {
            return [
                'valid' => false,
                'value' => substr($designation, 0, 100),
                'error' => esc_html__('Designation is too long (max 100 characters)', 'ws-custom-testimonial-slider'),
            ];
        }

        // Check for potentially harmful content
        if (preg_match('/<script|javascript:|onerror=/i', $designation)) {
            return [
                'valid' => false,
                'value' => '',
                'error' => esc_html__('Designation contains invalid content', 'ws-custom-testimonial-slider'),
            ];
        }

        return [
            'valid' => true,
            'value' => $designation,
            'error' => null,
        ];
    }

    /**
     * Validate social media URL
     * 
     * Rules:
     * - Max 500 characters
     * - Only http/https protocols
     * - No javascript:, data:, vbscript:, file:
     * - Valid URL format
     *
     * @param string $url The URL to validate
     * @return array ['valid' => bool, 'value' => string, 'error' => string|null]
     */
    public static function validate_social_url(string $url): array
    {
        $url = trim($url);

        // Allow empty URLs
        if (empty($url)) {
            return [
                'valid' => true,
                'value' => '',
                'error' => null,
            ];
        }

        // Check URL length (max 500 characters)
        if (strlen($url) > 500) {
            return [
                'valid' => false,
                'value' => '',
                'error' => esc_html__('URL is too long (max 500 characters)', 'ws-custom-testimonial-slider'),
            ];
        }

        // Sanitize URL
        $sanitized = esc_url_raw($url, ['http', 'https']);

        // Check if URL is valid after sanitization
        if (! $sanitized || ! wp_http_validate_url($sanitized)) {
            return [
                'valid' => false,
                'value' => '',
                'error' => esc_html__('Invalid URL format', 'ws-custom-testimonial-slider'),
            ];
        }

        // Additional validation: Check protocol
        if (! preg_match('/^https?:\/\//i', $sanitized)) {
            return [
                'valid' => false,
                'value' => '',
                'error' => esc_html__('URL must start with http:// or https://', 'ws-custom-testimonial-slider'),
            ];
        }

        // Check for suspicious patterns
        $suspicious_patterns = [
            'javascript:',
            'data:',
            'vbscript:',
            'file:',
        ];

        foreach ($suspicious_patterns as $pattern) {
            if (stripos($sanitized, $pattern) !== false) {
                return [
                    'valid' => false,
                    'value' => '',
                    'error' => esc_html__('URL contains invalid protocol', 'ws-custom-testimonial-slider'),
                ];
            }
        }

        return [
            'valid' => true,
            'value' => $sanitized,
            'error' => null,
        ];
    }

    /**
     * Validate social icon
     * 
     * Must be in whitelist of allowed icons
     * Defaults to 'website' if invalid
     *
     * @param string $icon The icon name
     * @return array ['valid' => bool, 'value' => string, 'error' => string|null]
     */
    public static function validate_social_icon(string $icon): array
    {
        $icon = sanitize_key($icon);
        $allowed = wscts_allowed_social_icons();

        if (! in_array($icon, $allowed, true)) {
            return [
                'valid' => true, // Default to 'website' is acceptable
                'value' => 'website',
                'error' => null,
            ];
        }

        return [
            'valid' => true,
            'value' => $icon,
            'error' => null,
        ];
    }

    /**
     * Validate widget settings before rendering
     *
     * @param array $settings Widget settings
     * @return array Validated settings
     */
    public static function validate_widget_settings(array $settings): array
    {
        // Validate slides_per_view
        if (isset($settings['slides_per_view'])) {
            $value = absint($settings['slides_per_view']);
            $settings['slides_per_view'] = max(1, min(5, $value));
        }

        // Validate effect
        $allowed_effects = ['slide', 'fade'];
        if (isset($settings['effect'])) {
            $settings['effect'] = in_array($settings['effect'], $allowed_effects, true)
                ? $settings['effect']
                : 'slide';
        }

        // Validate thumbnail_position
        $allowed_positions = ['top', 'bottom'];
        if (isset($settings['thumbnail_position'])) {
            $settings['thumbnail_position'] = in_array($settings['thumbnail_position'], $allowed_positions, true)
                ? $settings['thumbnail_position']
                : 'top';
        }

        // Validate nav_type
        $allowed_nav = ['arrows', 'dots', 'both', 'none'];
        if (isset($settings['nav_type'])) {
            $settings['nav_type'] = in_array($settings['nav_type'], $allowed_nav, true)
                ? $settings['nav_type']
                : 'both';
        }

        // Validate numeric fields
        if (isset($settings['autoplay_speed'])) {
            $settings['autoplay_speed'] = max(100, absint($settings['autoplay_speed']));
        }

        if (isset($settings['transition_speed'])) {
            $settings['transition_speed'] = max(100, absint($settings['transition_speed']));
        }

        return $settings;
    }

    /**
     * Check REST permission for reading testimonials
     * Public read access allowed
     *
     * @return bool Always returns true for public access
     */
    public static function check_rest_read_permission()
    {
        return true;
    }

    /**
     * Check REST permission for editing testimonials
     * Only authenticated users with edit capabilities
     *
     * @param WP_Post $post Post object (optional)
     * @return bool True if user can edit
     */
    public static function check_rest_edit_permission($post = null)
    {
        if ($post) {
            return current_user_can('edit_post', $post->ID);
        }

        return current_user_can('edit_testimonials');
    }

    /**
     * Check REST permission for meta field access
     * Allows public read, authenticated edit
     *
     * @param bool   $allowed Whether the user can access the data
     * @param string $meta_key The meta key being accessed
     * @param int    $post_id The post ID
     * @return bool
     */
    public static function check_rest_meta_permission($allowed, $meta_key, $post_id)
    {
        // For reading, allow if user can read the post
        if (! is_user_logged_in()) {
            return true; // Allow public to read meta
        }

        // For editing, check if user can edit the post
        return current_user_can('edit_post', $post_id);
    }
}
