<?php

namespace WSCTS;

if (! defined('ABSPATH')) {
    exit;
}

class Widgets
{
    public static function init(): void
    {
        add_action('elementor/widgets/register', [self::class, 'register_widgets']);
    }

    public static function register_widgets($widgets_manager): void
    {
        if (! class_exists('\Elementor\Widget_Base')) {
            return;
        }

        require_once __DIR__ . '/../widgets/class-custom-testimonial-slider.php';

        $widgets_manager->register(new \WSCTS\Custom_Testimonial_Slider());
    }
}
