<?php

namespace WSCTS;

if (! defined('ABSPATH')) {
    exit;
}

class Seeder
{
    public static function seed_dummy_testimonials(): void
    {
        // Prevent duplicate seeding.
        $already = (int) get_option('wscts_dummy_testimonials_seeded', 0);
        if ($already === 1) {
            return;
        }

        // Always register CPT to make sure insertion works.
        Post_Type::register_post_type();

        // Ensure the post type exists.
        if (! post_type_exists('custom-testimonial')) {
            Post_Type::register_post_type();
        }

        $posts_count = 10;
        $existing = (int) wp_count_posts('custom-testimonial')->publish;
        if ($existing > 0) {
            // If the site already has content, don't overwrite/duplicate it.
            update_option('wscts_dummy_testimonials_seeded', 1, false);
            return;
        }

        $demo_designations = [
            'Financial Advisor',
            'Wealth Strategist',
            'Investment Analyst',
            'Retirement Planner',
            'Tax Specialist',
            'Portfolio Manager',
            'Client Success Lead',
            'Risk Analyst',
            'Operations Director',
        ];

        $demo_names = [
            'John Doe',
            'Sarah Johnson',
            'Michael Brown',
            'Emily Davis',
            'Daniel Wilson',
            'Sophia Martinez',
            'David Anderson',
            'Olivia Thomas',
            'James Taylor',
            'Ava Jackson',
        ];

        // Simple social sets; real icons are generated in the widget from meta.
        $demo_socials = [
            [
                ['icon' => 'linkedin', 'url' => 'https://linkedin.com'],
                ['icon' => 'website', 'url' => 'https://example.com'],
            ],
            [
                ['icon' => 'facebook', 'url' => 'https://facebook.com'],
                ['icon' => 'website', 'url' => 'https://example.com'],
            ],
            [
                ['icon' => 'instagram', 'url' => 'https://instagram.com'],
                ['icon' => 'website', 'url' => 'https://example.com'],
            ],
            [
                ['icon' => 'x', 'url' => 'https://x.com'],
                ['icon' => 'website', 'url' => 'https://example.com'],
            ],
            [
                ['icon' => 'youtube', 'url' => 'https://youtube.com'],
                ['icon' => 'website', 'url' => 'https://example.com'],
            ],
            [
                ['icon' => 'tiktok', 'url' => 'https://tiktok.com'],
                ['icon' => 'website', 'url' => 'https://example.com'],
            ],
        ];
        $image_sources = self::get_feature_image_sources();

        for ($i = 1; $i <= $posts_count; $i++) {
            $name = $demo_names[$i - 1] ?? ('Testimonial ' . $i);
            $designation = $demo_designations[$i - 1] ?? 'Financial Advisor';
            $social_set = $demo_socials[($i - 1) % count($demo_socials)] ?? [];

            $post_id = wp_insert_post([
                'post_type' => 'custom-testimonial',
                'post_status' => 'publish',
                'post_title' => $name,
                'post_content' => sprintf(
                    '<p>%s</p>',
                    esc_html__('“Reasy made the process simple and the results exceeded our expectations.”', 'ws-custom-testimonial-slider')
                ),
            ], true);

            if (is_wp_error($post_id) || ! $post_id) {
                continue;
            }

            update_post_meta($post_id, 'designation', $designation);
            update_post_meta($post_id, 'social_icons', $social_set);

            if (! empty($image_sources)) {
                self::attach_featured_image_from_source($post_id, $image_sources[($i - 1) % count($image_sources)]);
            }
        }

        update_option('wscts_dummy_testimonials_seeded', 1, false);
    }

    public static function attach_demo_thumbnails_to_existing(): void
    {
        // Ensure CPT exists.
        Post_Type::register_post_type();

        $posts = get_posts([
            'post_type' => 'custom-testimonial',
            'posts_per_page' => -1,
            'post_status' => 'publish',
        ]);

        if (empty($posts)) {
            return;
        }

        $image_sources = self::get_feature_image_sources();

        if (empty($image_sources)) {
            return;
        }

        foreach ($posts as $index => $post) {
            $post_id = $post->ID;
            if (has_post_thumbnail($post_id)) {
                continue;
            }

            $source = $image_sources[$index % count($image_sources)];
            self::attach_featured_image_from_source($post_id, $source);
        }
    }

    protected static function attach_featured_image_from_source(int $post_id, string $source): bool
    {
        if ($post_id <= 0 || ! file_exists($source) || ! is_readable($source)) {
            return false;
        }

        self::load_media_functions();

        $upload = wp_upload_dir();
        if (! empty($upload['error']) || empty($upload['path']) || empty($upload['url'])) {
            return false;
        }

        if (! wp_mkdir_p($upload['path'])) {
            return false;
        }

        $dest_filename = wp_unique_filename($upload['path'], sanitize_file_name(basename($source)));
        $dest_path = trailingslashit($upload['path']) . $dest_filename;
        $dest_url = trailingslashit($upload['url']) . rawurlencode($dest_filename);

        if (! @copy($source, $dest_path)) {
            return false;
        }

        $filetype = wp_check_filetype($dest_filename, null);
        if (empty($filetype['type']) || 0 !== strpos($filetype['type'], 'image/')) {
            wp_delete_file($dest_path);

            return false;
        }

        $attachment = [
            'guid' => $dest_url,
            'post_mime_type' => $filetype['type'],
            'post_title' => sanitize_text_field(pathinfo($dest_filename, PATHINFO_FILENAME)),
            'post_content' => '',
            'post_status' => 'inherit',
        ];

        $attach_id = wp_insert_attachment($attachment, $dest_path, $post_id);
        if (is_wp_error($attach_id) || ! $attach_id) {
            wp_delete_file($dest_path);

            return false;
        }

        $attach_data = wp_generate_attachment_metadata($attach_id, $dest_path);
        wp_update_attachment_metadata($attach_id, $attach_data);

        return (bool) set_post_thumbnail($post_id, $attach_id);
    }

    protected static function load_media_functions(): void
    {
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
    }

    protected static function get_feature_image_sources(): array
    {
        $base_path = WSCTS_PATH . 'assets/images';

        if (! is_dir($base_path)) {
            return [];
        }

        $allowed_extensions = ['gif', 'jpeg', 'jpg', 'png', 'webp'];
        $sources = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($base_path, \FilesystemIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if (! $file instanceof \SplFileInfo || ! $file->isFile()) {
                continue;
            }

            $extension = strtolower($file->getExtension());

            if (in_array($extension, $allowed_extensions, true)) {
                $sources[] = $file->getPathname();
            }
        }

        natsort($sources);

        return array_values($sources);
    }
}
