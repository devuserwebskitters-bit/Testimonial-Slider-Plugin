<?php

namespace WSCTS;

if (! defined('ABSPATH')) {
    exit;
}

function plugin_url(string $path = ''): string
{
    return WSCTS_URL . ltrim($path, '/');
}

function wscts_allowed_social_icons(): array
{
    return ['facebook', 'instagram', 'linkedin', 'x', 'youtube', 'tiktok', 'website'];
}

function wscts_sanitize_social_url(string $url): string
{
    $url = esc_url_raw($url, ['http', 'https']);

    return $url ?: '';
}

function social_icon_html(string $icon): string
{
    $map = [
        'facebook' => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M14 8.5h2.4V5.1c-.4-.1-1.8-.2-3.4-.2-3.3 0-5.6 2.1-5.6 5.9v3.3H4v3.8h3.4V24h4.1v-6.1h3.2l.5-3.8h-3.7v-2.9c0-1.1.3-1.9 2.5-1.9z"/></svg>',
        'instagram' => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4c0 3.2-2.6 5.8-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8C2 4.6 4.6 2 7.8 2zm0 2A3.8 3.8 0 0 0 4 7.8v8.4A3.8 3.8 0 0 0 7.8 20h8.4a3.8 3.8 0 0 0 3.8-3.8V7.8A3.8 3.8 0 0 0 16.2 4H7.8zm8.7 2.5a1.1 1.1 0 1 1 0 2.2 1.1 1.1 0 0 1 0-2.2zM12 7.4a4.6 4.6 0 1 1 0 9.2 4.6 4.6 0 0 1 0-9.2zm0 2a2.6 2.6 0 1 0 0 5.2 2.6 2.6 0 0 0 0-5.2z"/></svg>',
        'linkedin' => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5.3 8.9H1.7V22h3.6V8.9zM3.5 2.5a2.1 2.1 0 1 0 0 4.2 2.1 2.1 0 0 0 0-4.2zM22.3 14.8c0-3.9-2.1-6.2-5.2-6.2-2.4 0-3.5 1.3-4.1 2.2V8.9H9.5V22H13v-6.5c0-1.7.3-3.4 2.5-3.4 2.1 0 2.1 2 2.1 3.5V22h3.6v-7.2z"/></svg>',
        'x' => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M14.4 10.4 22.1 2h-1.8l-6.7 7.3L8.3 2H2.1l8.1 11.1L2.1 22h1.8l7.1-7.8 5.7 7.8h6.2l-8.5-11.6zM11.9 13.1l-.8-1.1L4.6 3.4h2.8l5.2 7 .8 1.1 6.9 9.2h-2.8l-5.6-7.6z"/></svg>',
        'youtube' => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2 31.2 31.2 0 0 0 0 12a31.2 31.2 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1A31.2 31.2 0 0 0 24 12a31.2 31.2 0 0 0-.5-5.8zM9.6 15.6V8.4l6.3 3.6-6.3 3.6z"/></svg>',
        'tiktok' => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M17.2 2c.4 3 2.1 4.8 4.8 5v3.4a8.5 8.5 0 0 1-4.7-1.5v6.6c0 4.2-2.6 6.5-6.3 6.5A6.2 6.2 0 0 1 4.8 16c0-3.8 3-6.3 6.7-6.1v3.5c-1.7-.3-3.2.7-3.2 2.5 0 1.6 1.1 2.6 2.6 2.6 1.7 0 2.8-1 2.8-3.3V2h3.5z"/></svg>',
        'website' => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M10.6 13.4a1.4 1.4 0 0 1 0-2l3.1-3.1a3 3 0 0 1 4.2 4.2l-2 2a1 1 0 1 0 1.4 1.4l2-2a5 5 0 0 0-7-7l-3.1 3.1a3.4 3.4 0 0 0 0 4.8 1 1 0 0 0 1.4-1.4zm2.8-2.8a1.4 1.4 0 0 1 0 2l-3.1 3.1a3 3 0 1 1-4.2-4.2l2-2A1 1 0 0 0 6.7 8l-2 2a5 5 0 1 0 7 7l3.1-3.1a3.4 3.4 0 0 0 0-4.8 1 1 0 0 0-1.4 1.4z"/></svg>',
    ];

    $icon = sanitize_key($icon);

    return $map[$icon] ?? $map['website'];
}

/**
 * Returns the allowed HTML tags/attributes for inline SVG icon output.
 * Used with wp_kses() when echoing social_icon_html().
 *
 * @return array<string, array<string, bool>>
 */
function wscts_svg_kses_allowed(): array
{
    return [
        'svg'  => [
            'viewbox'        => true,
            'aria-hidden'    => true,
            'focusable'      => true,
            'xmlns'          => true,
            'width'          => true,
            'height'         => true,
            'fill'           => true,
            'class'          => true,
            'role'           => true,
            'aria-label'     => true,
        ],
        'path' => [
            'd'              => true,
            'fill'           => true,
            'fill-rule'      => true,
            'clip-rule'      => true,
        ],
        'circle' => [
            'cx'             => true,
            'cy'             => true,
            'r'              => true,
            'fill'           => true,
        ],
        'rect'  => [
            'x'              => true,
            'y'              => true,
            'width'          => true,
            'height'         => true,
            'rx'             => true,
            'fill'           => true,
        ],
    ];
}
