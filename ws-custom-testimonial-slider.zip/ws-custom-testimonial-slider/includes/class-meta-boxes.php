<?php

namespace WSCTS;

if (! defined('ABSPATH')) {
    exit;
}

class Meta_Boxes
{
    public static function init(): void
    {
        add_action('add_meta_boxes', [self::class, 'add_meta_boxes']);
        add_action('save_post', [self::class, 'save_meta'], 10, 2);
        add_action('admin_enqueue_scripts', [self::class, 'admin_assets']);
    }

    public static function add_meta_boxes(): void
    {
        add_meta_box(
            'wscts_meta',
            __('Testimonial Details', 'ws-custom-testimonial-slider'),
            [self::class, 'render_meta_box'],
            'custom-testimonial',
            'normal',
            'default'
        );
    }

    public static function render_meta_box($post): void
    {
        wp_nonce_field('wscts_save_meta', 'wscts_meta_nonce');

        $designation = get_post_meta($post->ID, 'designation', true);
        $socials = get_post_meta($post->ID, 'social_icons', true);
        if (! is_array($socials)) {
            $socials = [];
        }

        ?>
        <p>
            <label for="wscts_designation"><?php esc_html_e('Designation', 'ws-custom-testimonial-slider'); ?></label>
            <input type="text" id="wscts_designation" name="wscts_designation" value="<?php echo esc_attr($designation); ?>" class="widefat" />
        </p>

        <div id="wscts_socials_wrap">
            <h4><?php esc_html_e('Social Icons', 'ws-custom-testimonial-slider'); ?></h4>
            <table id="wscts_socials_table" class="widefat">
                <thead>
                <tr>
                    <th><?php esc_html_e('Icon', 'ws-custom-testimonial-slider'); ?></th>
                    <th><?php esc_html_e('URL', 'ws-custom-testimonial-slider'); ?></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($socials as $index => $row) :
                    $icon = isset($row['icon']) ? $row['icon'] : '';
                    $url = isset($row['url']) ? $row['url'] : '';
                    ?>
                    <tr>
                        <td>
                            <select name="wscts_socials[<?php echo esc_attr($index); ?>][icon]">
                                <?php
                                $opts = wscts_allowed_social_icons();
                                foreach ($opts as $opt) :
                                    printf(
                                        '<option value="%1$s" %2$s>%3$s</option>',
                                        esc_attr($opt),
                                        selected($icon, $opt, false),
                                        esc_html($opt)
                                    );
                                endforeach;
                                ?>
                            </select>
                        </td>
                        <td>
                            <input type="url" name="wscts_socials[<?php echo esc_attr($index); ?>][url]" value="<?php echo esc_attr($url); ?>" class="widefat" />
                        </td>
                        <td>
                            <button type="button" class="button wscts-remove-row"><?php esc_html_e('Remove', 'ws-custom-testimonial-slider'); ?></button>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <p>
                <button type="button" id="wscts_add_row" class="button button-primary"><?php esc_html_e('Add Social', 'ws-custom-testimonial-slider'); ?></button>
            </p>
        </div>

        <?php
    }

    public static function admin_assets(string $hook_suffix = ''): void
    {
        $screen = get_current_screen();

        if (! $screen || 'custom-testimonial' !== $screen->post_type) {
            return;
        }

        wp_enqueue_script('wscts-admin', WSCTS_URL . 'assets/js/admin.js', ['jquery'], WSCTS_VERSION, true);
        wp_localize_script(
            'wscts-admin',
            'wsctsAdmin',
            [
                'icons' => wscts_allowed_social_icons(),
                'removeLabel' => __('Remove', 'ws-custom-testimonial-slider'),
            ]
        );
        wp_enqueue_style('wscts-admin', WSCTS_URL . 'assets/css/editor.css', [], WSCTS_VERSION);
    }

    public static function save_meta($post_id, $post): void
    {
        if (! isset($_POST['wscts_meta_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wscts_meta_nonce'])), 'wscts_save_meta')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if ('custom-testimonial' !== $post->post_type) {
            return;
        }

        if (wp_is_post_revision($post_id) || ! current_user_can('edit_post', $post_id)) {
            return;
        }

        if (isset($_POST['wscts_designation']) && is_scalar($_POST['wscts_designation'])) {
            update_post_meta($post_id, 'designation', sanitize_text_field(wp_unslash((string) $_POST['wscts_designation'])));
        }

        if (isset($_POST['wscts_socials']) && is_array($_POST['wscts_socials'])) {
            $san = [];
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each field is sanitized individually below
            $social_rows = wp_unslash( (array) $_POST['wscts_socials'] );
            $allowed_icons = array_fill_keys(wscts_allowed_social_icons(), true);

            foreach ($social_rows as $row) {
                if (! is_array($row)) {
                    continue;
                }

                $icon = isset($row['icon']) && is_scalar($row['icon']) ? sanitize_key((string) $row['icon']) : '';
                $url  = isset($row['url'])  && is_scalar($row['url'])  ? wscts_sanitize_social_url( sanitize_text_field( (string) $row['url'] ) ) : '';

                if (! isset($allowed_icons[$icon])) {
                    $icon = 'website';
                }

                if ($url) {
                    $san[] = ['icon' => $icon, 'url' => $url];
                }
            }
            update_post_meta($post_id, 'social_icons', $san);
        } else {
            delete_post_meta($post_id, 'social_icons');
        }
    }
}
