# WS Custom Testimonial Slider

Custom testimonial slider plugin for WordPress with an Elementor widget, a `custom-testimonial` post type, seeded demo testimonials, and bundled Slick carousel assets.

## Requirements

- WordPress 6.5+
- PHP 8.0+
- Elementor for editing/placing the widget

Elementor is not required for activation. The plugin can still register the testimonial post type and seed demo content when Elementor is inactive.

## Installation

1. Upload this folder to `wp-content/plugins/`.
2. Activate **WS Custom Testimonial Slider** in WordPress admin.
3. Confirm **Custom Testimonials** appears in the admin menu.
4. Activate Elementor and add the **Custom Testimonial Slider** widget to a page.

On first activation, the plugin creates demo testimonials and attaches supported image files from `assets/images/` as real Featured Images. Images can be placed directly in `assets/images/` or inside child folders such as `assets/images/demo/`.

## Folder Structure

- `ws-custom-testimonial-slider.php` - plugin bootstrap, constants, and runner.
- `includes/` - activation, CPT, meta boxes, asset registration, Elementor registration, seeding, and helpers.
- `widgets/` - Elementor widget class and render logic.
- `assets/css/` - frontend, editor, and Slick styles.
- `assets/js/` - frontend slider initialization, admin meta-box UI, and Slick.
- `assets/images/` - testimonial images used for seeded Featured Images; `assets/images/demo/` also provides frontend fallback thumbnails.
- `readme.txt` - WordPress plugin readme.
- `AI_USAGE_REPORT.md` - AI assistance and verification notes.

## Security And Validation

- Direct PHP file access is blocked with `ABSPATH` checks.
- Meta saves verify a nonce and check autosave, revision, post type, and `edit_post` capability.
- Text values are sanitized with WordPress helpers.
- Social icons are restricted to a fixed allowlist.
- Social URLs are stored only when they pass `http`/`https` URL sanitization.
- Frontend output uses `esc_html`, `esc_attr`, `esc_url`, and `wp_kses_post` as appropriate.
- Demo images are copied and attached through WordPress media APIs.

## Widget Features

- Responsive thumbnail count: desktop, tablet, and mobile.
- Thumbnail position: top or bottom.
- Slide or fade effect.
- Autoplay, infinite loop, pause on hover, transition speed.
- Arrows, dots, both, or no navigation.
- Style controls for container, arrows, dots, thumbnails, social icons, and testimonial content.

## Verification

Run PHP syntax checks from the plugin folder:

```bash
find . -type f -name '*.php' -print0 | xargs -0 -n 50 php -l
```
